package emp;

import java.util.HashMap;

public class EmpDataSet  {
	public static HashMap<String,EmpVO> empList = new HashMap<String,EmpVO>();
	public EmpDataSet() {
		
	}
	public static void setEmpList() {
		empList.put("이경용",new EmpVO(1,"이경용","010-1234-5678","총무부","대표"));

		empList.put("박수빈",new EmpVO(2,"박수빈","010-2345-6789","기획부","과장"));

		empList.put("최하나",new EmpVO(3,"최하나","010-0094-4567","행정부","사원"));

		empList.put("김슬기",new EmpVO(4,"김슬기","010-2347-3435","인사부","대리"));

		empList.put("이지수",new EmpVO(5,"이지수","010-3412-1234","행정부","인턴"));
	}
}
