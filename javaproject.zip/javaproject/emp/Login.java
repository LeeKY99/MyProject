package emp;

public class Login extends Thread {
	public static String id;
	public static String pwd;
	public static int n = 0;
	
	public Login() {}
	
	public static boolean LoginCheck() {
		if ( id == "" || pwd == "") {
			System.out.println("아이디와 비밀번호를 입력 후 로그인하세요.");
			System.out.println("id -----"+id+" password ----" + pwd);
			return false;
		}else {
			if(id.equals("admin") && pwd.equals("1234")){
				return true;
			}else {
				System.out.println("아이디와 비밀번호가 일치하지않습니다. \n" +"입력하신ID -----"+id+"\n입력하신Password----"+pwd);
				return false;
			}	
		}
	}
}


