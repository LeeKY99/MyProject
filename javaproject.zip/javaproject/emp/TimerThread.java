package emp;
import Project.EmpMain;

public class TimerThread extends Thread {
	
	public void run() {
		for(int i = 30; i>=1; i--) {
			if(EmpMain.inputCheck == true) {
				return;
			}
			try {
				Thread.sleep(1000);
			} catch(InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("로그인 시간이 초과되었습니다.");
		System.exit(0);
	}
}
