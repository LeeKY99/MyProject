package emp;

public class EmpVO {
	private int empNo;
	private String empName;
	private String tel;
	private String depart;
	private String position;
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
		if(empNo <= 0) {
			System.out.println("양수를 입력해주세요");
		} if(empNo > 100) {
			System.out.println("사원수를 초과하였습니다.");
		}
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getDepart() {
		return depart;
	}
	public void setDepart(String depart) {
		switch(depart) {
		case "총무부":
			this.depart = depart;
			break;
		case "기획부":
			this.depart = depart;
			break;
		case "영업부":
			this.depart = depart;
			break;
		case "행정부":
			this.depart = depart;
			break;
		case "인사부":
			this.depart = depart;
			break;
		case "법무부":
			this.depart = depart;
			break;
		default:
			this.depart = "배정되지않음";
			System.out.println("없는 부서입니다.");
		}
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		switch(position) {
		case "대표":
			this.position = position;
			break;
		case "과장":
			this.position = position;
			break;
		case "팀장":
			this.position = position;
			break;
		case "대리":
			this.position = position;
			break;
		case "주임":
			this.position = position;
			break;
		case "사원":
			this.position = position;
			break;
		case "인턴":
			this.position = position;
			break;
		default:
			this.position = "무직책";
			System.out.println("적합한 직책이 아닙니다.");
			}


		
	}
	
	public EmpVO() {
	}
	public EmpVO(int empNo, String empName, String tel, String depart, String position) {
		super();
		this.empNo = empNo;
		this.empName = empName;
		this.tel = tel;
		this.depart = depart;
		this.position = position;
	}
	@Override
	public String toString() {
		return "EmpVO [empNo=" + empNo + ", empName=" + empName + ", tel=" + tel + ", depart=" + depart + ", position="
				+ position + "]";
	}
	
	
	
	
	
}
